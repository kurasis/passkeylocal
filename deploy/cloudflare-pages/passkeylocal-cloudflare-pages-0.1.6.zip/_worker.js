//#region src/favicon/domain.ts
function e(e) {
	if (!e || e.length > 253 || e !== e.toLowerCase() || e.endsWith(".")) return null;
	let t = e.split(".");
	return t.length < 2 || t.some((e) => !/^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/.test(e)) || !/^(?:[a-z]{2,63}|xn--[a-z0-9-]{2,59})$/.test(t.at(-1)) || [
		"localhost",
		"local",
		"internal",
		"lan",
		"home",
		"arpa",
		"test",
		"invalid",
		"example",
		"onion"
	].includes(t.at(-1)) ? null : e;
}
function t(e) {
	if (e.length < 24 || e.length > 65536) return !1;
	let t = new DataView(e.buffer, e.byteOffset, e.byteLength);
	if (t.getUint32(0) === 2303741511 && t.getUint32(4) === 218765834 && t.getUint32(12) === 1229472850) {
		let e = t.getUint32(16), n = t.getUint32(20);
		return e > 0 && n > 0 && e <= 512 && n <= 512;
	}
	if (t.getUint32(0, !0) !== 65536) return !1;
	let n = t.getUint16(4, !0);
	if (!n || n > 32 || 6 + 16 * n > e.length) return !1;
	for (let r = 0; r < n; r++) {
		let i = 6 + 16 * r, a = t.getUint32(i + 8, !0), o = t.getUint32(i + 12, !0);
		if (!a || o < 6 + 16 * n || o + a > e.length) return !1;
		if (a >= 24 && t.getUint32(o) === 2303741511) {
			if (t.getUint32(o + 16) !== (e[i] || 256) || t.getUint32(o + 20) !== (e[i + 1] || 256)) return !1;
		} else if (a < 40 || t.getUint32(o, !0) < 40 || t.getInt32(o + 4, !0) !== (e[i] || 256) || Math.abs(t.getInt32(o + 8, !0)) !== 2 * (e[i + 1] || 256)) return !1;
	}
	return !0;
}
//#endregion
//#region server/favicon-worker.ts
var n = {
	"Cache-Control": "no-store",
	"X-Content-Type-Options": "nosniff",
	"Referrer-Policy": "no-referrer"
}, r = () => new Response(null, {
	status: 404,
	headers: n
});
function i(t, n, r) {
	if (!r) return null;
	let i = t.startsWith("www.") ? t.slice(4) : `www.${t}`;
	if (!e(i)) return null;
	let a = `https://${i}${n}`;
	return r === a ? a : null;
}
async function a(a, o = fetch) {
	if (a.method !== "POST") return new Response(null, {
		status: 405,
		headers: {
			...n,
			Allow: "POST"
		}
	});
	let s = a.headers.get("origin");
	if (s && s !== new URL(a.url).origin || a.headers.get("sec-fetch-site") === "cross-site" || !a.headers.get("content-type")?.startsWith("application/json")) return new Response(null, {
		status: 403,
		headers: n
	});
	let c = a.body?.getReader();
	if (!c) return r();
	let l = "";
	try {
		let e = new TextDecoder();
		for (;;) {
			let { done: t, value: n } = await c.read();
			if (t) break;
			if (l.length + n.length > 1024) return r();
			l += e.decode(n, { stream: !0 });
		}
	} finally {
		await c.cancel().catch(() => {});
	}
	let u;
	try {
		let t = JSON.parse(l);
		u = typeof t.domain == "string" ? e(t.domain) : null;
	} catch {
		return r();
	}
	if (!u) return r();
	let d = AbortSignal.timeout(8e3), f = !1;
	for (let e of ["/favicon.ico", "/apple-touch-icon.png"]) {
		let r = [`https://${u}${e}`];
		for (let a of r) try {
			let s = await o(a, {
				redirect: "manual",
				credentials: "omit",
				referrerPolicy: "no-referrer",
				signal: d,
				cache: "no-store",
				headers: { Accept: "image/png,image/x-icon,image/vnd.microsoft.icon" }
			});
			if ([
				301,
				302,
				303,
				307,
				308
			].includes(s.status) && r.length === 1) {
				let t = i(u, e, s.headers.get("location"));
				if (t) {
					await s.body?.cancel(), r.push(t);
					continue;
				}
			}
			if (!s.ok && s.status !== 404 && s.status !== 410 && (f = !0), !s.ok || Number(s.headers.get("content-length")) > 65536) {
				await s.body?.cancel();
				continue;
			}
			let c = s.body?.getReader();
			if (!c) continue;
			let l = /* @__PURE__ */ new Uint8Array(65536), p = 0, m = !1;
			try {
				for (;;) {
					let { done: e, value: t } = await c.read();
					if (e) break;
					if (p + t.length > l.length) {
						m = !0;
						break;
					}
					l.set(t, p), p += t.length;
				}
			} finally {
				await c.cancel().catch(() => {});
			}
			let h = l.slice(0, p);
			if (!m && t(h)) return new Response(h, { headers: {
				...n,
				"Content-Type": "application/octet-stream"
			} });
		} catch {
			f = !0;
		}
	}
	return f ? new Response(null, {
		status: 503,
		headers: n
	}) : new Response(null, {
		status: 404,
		headers: {
			...n,
			"X-PassKey-Favicon": "missing"
		}
	});
}
var o = { async fetch(e, t) {
	if (new URL(e.url).pathname !== "/api/favicon") return t.ASSETS.fetch(e);
	try {
		return await a(e);
	} catch {
		return r();
	}
} };
//#endregion
export { o as default, a as faviconRequest };
