//#region src/favicon/domain.ts
function e(e) {
	if (!e || e.length > 253 || e !== e.toLowerCase() || e.endsWith(".")) return null;
	let t = e.split(".");
	return t.length < 2 || t.some((e) => !/^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/.test(e)) || !/^(?:[a-z]{2,63}|xn--[a-z0-9-]{2,59})$/.test(t.at(-1)) || [
		"localhost",
		"local",
		"internal",
		"lan",
		"home",
		"arpa",
		"test",
		"invalid",
		"example",
		"onion"
	].includes(t.at(-1)) ? null : e;
}
function t(e) {
	if (e.length < 24 || e.length > 65536) return !1;
	let t = new DataView(e.buffer, e.byteOffset, e.byteLength);
	if (t.getUint32(0) === 2303741511 && t.getUint32(4) === 218765834 && t.getUint32(12) === 1229472850) {
		let e = t.getUint32(16), n = t.getUint32(20);
		return e > 0 && n > 0 && e <= 512 && n <= 512;
	}
	if (t.getUint32(0, !0) !== 65536) return !1;
	let n = t.getUint16(4, !0);
	if (!n || n > 32 || 6 + 16 * n > e.length) return !1;
	for (let r = 0; r < n; r++) {
		let i = 6 + 16 * r, a = t.getUint32(i + 8, !0), o = t.getUint32(i + 12, !0);
		if (!a || o < 6 + 16 * n || o + a > e.length) return !1;
		if (a >= 24 && t.getUint32(o) === 2303741511) {
			if (t.getUint32(o + 16) !== (e[i] || 256) || t.getUint32(o + 20) !== (e[i + 1] || 256)) return !1;
		} else if (a < 40 || t.getUint32(o, !0) < 40 || t.getInt32(o + 4, !0) !== (e[i] || 256) || Math.abs(t.getInt32(o + 8, !0)) !== 2 * (e[i + 1] || 256)) return !1;
	}
	return !0;
}
//#endregion
//#region server/favicon-worker.ts
var n = {
	"Cache-Control": "no-store",
	"X-Content-Type-Options": "nosniff",
	"Referrer-Policy": "no-referrer"
}, r = () => new Response(null, {
	status: 404,
	headers: n
});
async function i(i, a = fetch) {
	if (i.method !== "POST") return new Response(null, {
		status: 405,
		headers: {
			...n,
			Allow: "POST"
		}
	});
	let o = i.headers.get("origin");
	if (o && o !== new URL(i.url).origin || i.headers.get("sec-fetch-site") === "cross-site" || !i.headers.get("content-type")?.startsWith("application/json")) return new Response(null, {
		status: 403,
		headers: n
	});
	let s = i.body?.getReader();
	if (!s) return r();
	let c = "";
	try {
		let e = new TextDecoder();
		for (;;) {
			let { done: t, value: n } = await s.read();
			if (t) break;
			if (c.length + n.length > 1024) return r();
			c += e.decode(n, { stream: !0 });
		}
	} finally {
		await s.cancel().catch(() => {});
	}
	let l;
	try {
		let t = JSON.parse(c);
		l = typeof t.domain == "string" ? e(t.domain) : null;
	} catch {
		return r();
	}
	if (!l) return r();
	let u = AbortSignal.timeout(8e3), d = !1;
	for (let e of ["/favicon.ico", "/apple-touch-icon.png"]) try {
		let r = await a(`https://${l}${e}`, {
			redirect: "manual",
			credentials: "omit",
			referrerPolicy: "no-referrer",
			signal: u,
			cache: "no-store",
			headers: { Accept: "image/png,image/x-icon,image/vnd.microsoft.icon" }
		});
		if (!r.ok && r.status !== 404 && r.status !== 410 && r.status >= 400 && (d = !0), !r.ok || Number(r.headers.get("content-length")) > 65536) {
			await r.body?.cancel();
			continue;
		}
		let i = r.body?.getReader();
		if (!i) continue;
		let o = /* @__PURE__ */ new Uint8Array(65536), s = 0, c = !1;
		try {
			for (;;) {
				let { done: e, value: t } = await i.read();
				if (e) break;
				if (s + t.length > o.length) {
					c = !0;
					break;
				}
				o.set(t, s), s += t.length;
			}
		} finally {
			await i.cancel().catch(() => {});
		}
		let f = o.slice(0, s);
		if (!c && t(f)) return new Response(f, { headers: {
			...n,
			"Content-Type": "application/octet-stream"
		} });
	} catch {
		d = !0;
	}
	return d ? new Response(null, {
		status: 503,
		headers: n
	}) : new Response(null, {
		status: 404,
		headers: {
			...n,
			"X-PassKey-Favicon": "missing"
		}
	});
}
var a = { async fetch(e, t) {
	if (new URL(e.url).pathname !== "/api/favicon") return t.ASSETS.fetch(e);
	try {
		return await i(e);
	} catch {
		return r();
	}
} };
//#endregion
export { a as default, i as faviconRequest };
