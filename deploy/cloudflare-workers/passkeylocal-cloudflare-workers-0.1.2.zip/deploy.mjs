import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';
const args = process.argv.slice(2);
if (args.length !== 1 || !/^[a-z0-9][a-z0-9-]{0,62}$/.test(args[0]) || /YOUR|replace/i.test(args[0])) {
  console.error('Usage: npm run deploy -- EXISTING_WORKER_NAME (copy its exact name from Cloudflare).');
  process.exit(1);
}
const cli = new URL('./node_modules/wrangler/bin/wrangler.js', import.meta.url);
const result = spawnSync(process.execPath, [fileURLToPath(cli), 'deploy', '--name', args[0], '--keep-vars'], { stdio: 'inherit' });
process.exit(result.status ?? 1);
